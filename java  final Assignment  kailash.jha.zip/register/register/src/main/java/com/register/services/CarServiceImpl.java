//package com.register.services;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.register.model.Car;
//import com.register.repository.CarRepository;
//import com.register.repository.UserRepository;
//@Service
//public class CarServiceImpl implements CarService{
//	
//	@Autowired
//	public CarRepository carRepository;
//	
//	@Override
//	public List<Car> findAllCars() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public Car findCarById(Long id) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public Car findByCarName(String CarName) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public void deleteCar(Long id) {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void addCar(Car car) {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void updateCar(Long id, Car updatedCar) {
//		// TODO Auto-generated method stub
//		
//	}
//
//}
package com.register.services;

import java.awt.print.Pageable;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.register.model.Car;
import com.register.repository.CarRepository;

@Service
public class CarServiceImpl implements CarService {

	@Autowired
	private CarRepository carRepository;
	private int page;
	private int pageSize;

	@Override
	public List<Car> findAllCars() {
		return carRepository.findAll();
	}

	@Override
	public Car findCarById(Integer id) {
		Optional<Car> optionalCar = carRepository.findById(id);
		return optionalCar.orElse(null);
	}

	@Override
	public Car findByCarName(String carName) {
		return carRepository.findByCarName(carName);
	}

	@Override
	public void deleteCar(Integer id) {
		carRepository.deleteById(id);
	}

	@Override
	public void addCar(Car car) {
		carRepository.save(car);
	}

	@Override
	public void updateCar(Integer id, Car updatedCar) {
		Optional<Car> optionalCar = carRepository.findById(id);
		if (optionalCar.isPresent()) {
			Car existingCar = optionalCar.get();
			existingCar.setModel(updatedCar.getModel());
			existingCar.setModel(updatedCar.getModel());
			existingCar.setColour(updatedCar.getColour());
			existingCar.setPrice(updatedCar.getPrice());
			carRepository.save(existingCar);
		}
	}

	@Override
    public Car buyCar(Integer id) throws Exception {
        Optional<Car> optionalCar = carRepository.findById(id);

        if (optionalCar.isPresent()) {
            Car carToBuy = optionalCar.get();

            if ("pending".equals(carToBuy.getStatus())) {
                carToBuy.setStatus("bought");
                carRepository.save(carToBuy);

                return carToBuy;
            } else {
                throw new Exception("Car with ID " + id + " is not available for purchase");
            }
        } else {
            throw new Exception("Car not found with ID: " + id);
        }
    }

	@Override
    public List<Car> getPendingCars() {
        return carRepository.findByStatus("pending");
    }

	@Override
	public Car getCarById(Integer carId) {
	    return carRepository.findById(carId).orElse(null);
	}

	@Override
	public Car updateCar(Integer carId, String status) {
	    Car existingCar = carRepository.findById(carId).orElse(null);

	    if (existingCar != null) {
	        existingCar.setStatus(status);
	        carRepository.save(existingCar);
	    }

	    return existingCar;
	}

	@Override
	public long getTotalCarCount() {
		// TODO Auto-generated method stub
		 return carRepository.count();
	}

	@Override
	public List<Car> getAllCars() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveCarWithImage(Car car, MultipartFile imageFile) throws IOException {
		// TODO Auto-generated method stub
		byte[] imageData = imageFile.getBytes();
        car.setImage(imageData);
        carRepository.save(car);
    }

	@Override
    public void addCarWithImage(Car car, MultipartFile image) {
        if (!image.isEmpty()) {
            byte[] bytes = null;
			try {
				bytes = image.getBytes();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            String fileName = System.currentTimeMillis() + "_" + image.getOriginalFilename();
            Path path = Paths.get("uploads/" + fileName); // Make sure "uploads" directory exists
            try {
				Files.write(path, bytes);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            car.setImage(fileName);
        }

        carRepository.save(car);
    }

	@Override
	public org.hibernate.query.Page findPaginated(int pageNo, int pageSize) {
		// TODO Auto-generated method stub
		Pageable pageable = (Pageable) PageRequest.of(pageNo, pageSize);
		
		return (org.hibernate.query.Page) carRepository.findAll();
	}

	@Override
	public Car getCarById(PageRequest pageRequest) {
		// TODO Auto-generated method stub
		
		return (Car) carRepository.findAll();
	}
}
