package com.register.services;

import java.awt.print.Pageable;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.hibernate.query.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.multipart.MultipartFile;

import com.register.model.Car;

public interface CarService {

//	List<Car> findAllCars();

	public List<Car> findAllCars();

	public Car findCarById(Integer id);

	public Car findByCarName(String CarName);

	public void deleteCar(Integer id);

	public void addCar(Car car);

	public void updateCar(Integer id, Car updatedCar);

	public Car buyCar(Integer id) throws Exception;

	public List<Car> getPendingCars();

	public Car getCarById(Integer carId);
	public Car getCarById(PageRequest pageRequest);

	public Car updateCar(Integer carId, String status);
	
	 long getTotalCarCount();

	 List<Car> getAllCars();
	    void saveCarWithImage(Car car, MultipartFile imageFile) throws IOException;

		public void addCarWithImage(Car car, MultipartFile image);
		
		Page findPaginated(int pageNo, int pageSize);

//		List<Car> searchCars(String keyword);

		
		
		
}
