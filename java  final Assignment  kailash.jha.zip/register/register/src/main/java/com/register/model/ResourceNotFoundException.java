package com.register.model;

public class ResourceNotFoundException extends RuntimeException {

	public ResourceNotFoundException(String string) {
		// TODO Auto-generated constructor stub
	}
    // Your custom implementation, if needed
}
