//package com.register.controller;
//
//import java.security.Principal;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.RequestMapping;
//
//import com.register.model.Car;
//import com.register.repository.UserRepository;
//
//@Controller
//@RequestMapping("/admin")
//public class AdminController {
//
//	@Autowired
//	private UserRepository userRepository;
//
//	@ModelAttribute
//	public void commonUser(Principal p, Model m) {
//		if (p != null) {
//			String email = p.getName();
//			Object user = userRepository.findByEmail(email);
//			m.addAttribute("user", user);
//		}
//	}
//
//	@GetMapping("/profile")
//	public String profile() {
//		return "admin_profile";
//	}
//	
//	/**Directs to add page through which user can add a car 
//	 * @return A HTML page which acts as add car page
//	 */
//	@GetMapping("/profile/list")
//	public String goToAddCarPage(Model model)
//	{
//		model.addAttribute("car", new Car());
//		return "car-list";
//	}
//	
//}

package com.register.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.ListCrudRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.register.model.Car;
import com.register.repository.CarRepository;
import com.register.repository.UserRepository;
import com.register.services.CarService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private UserRepository userRepository;
	private ListCrudRepository<Car, Integer> carRepository;
	@Autowired
	private CarService carService;
	private AdminController userService;

	@ModelAttribute
	public void commonUser(Principal p, Model m, HttpSession session) {
		if (p != null) {
			String email = p.getName();
			Object user = userRepository.findByEmail(email);
			m.addAttribute("user", user);

			// Save user information in the session
			session.setAttribute("user", user);
		}
	}

	@GetMapping("/profile")
	public String profile(Model model) {

        return "admin_profile";
	}
	
//	@GetMapping("/profile")
//	public String profile(Model model) {
//		List<Car> carServices = carService.getAllCar();
//	    model.addAttribute("car", carServices);
//
//	    return "admin_profile";
//	}

	@GetMapping("/users")
	public String listUsers(Model model) {
		List<com.register.model.User> users = userRepository.findAll();
		model.addAttribute("users", users);
		System.out.println("Number of users: " + users.size());
		return "user-list";
	}

	@PostMapping("/updateStatus/{userId}")
	public ResponseEntity<String> updateStatus(@PathVariable int userId, @RequestParam String status) {
		userService.updateStatus(userId, status);
		return ResponseEntity.ok("Status updated successfully");
	}

	@GetMapping("/profile/pending")
	public String getPendingCars(Model model, HttpSession session) {
		List<Car> pendingCars = carService.getPendingCars();
		model.addAttribute("cars", pendingCars);
		session.setAttribute("user", "JohnDoe");

		return "pending-cars-list";
	}

	@GetMapping("profile/request/{status}/{carId}")
	public String performRequest(Model model, @PathVariable int carId, @PathVariable String status,
			HttpSession session) {
		session.setAttribute("carId", carId);
		Car car1 = carService.findCarById(carId);
		if (status.equals("Deny")) {
			car1.setStatus("decline");
		} else if (status.equals("approve")) {
			car1.setStatus("sold");
		}

		carService.updateCar(carId, car1);
//	  System.out.println("hellofknv"+status);
		return "redirect:/admin/profile/pending";
	}


}
