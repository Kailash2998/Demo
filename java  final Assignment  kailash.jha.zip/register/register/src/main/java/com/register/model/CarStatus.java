package com.register.model;

public enum CarStatus {
    PENDING("Pending"),
    APPROVED("Approved"),
    DECLINED("Declined");

    private final String status;

    CarStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }
}
