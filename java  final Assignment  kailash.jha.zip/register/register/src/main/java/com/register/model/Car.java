package com.register.model;

import java.io.Serializable;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Car implements Serializable {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int carId;
	private String carName;
	private String brand;
	private String model;
	private String colour;
    private double price;
    private String status; 
    private String image;
    
	public Car(int carId, String carName, String brand, String model, String colour, double price, String status,
			String image) {
		super();
		this.carId = carId;
		this.carName = carName;
		this.brand = brand;
		this.model = model;
		this.colour = colour;
		this.price = price;
		this.status = status;
		this.image = image;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String fileName) {
		this.image = fileName;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getCarId() {
		return carId;
	}
	public void setCarId(int carId) {
		this.carId = carId;
	}
	public String getCarName() {
		return carName;
	}
	public void setCarName(String carName) {
		this.carName = carName;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getColour() {
		return colour;
	}
	public void setColour(String colour) {
		this.colour = colour;
	}
	public double getPrice() {
		return price;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Car(int carId, String carName, String brand, String model, String colour, double price, String status) {
		super();
		this.carId = carId;
		this.carName = carName;
		this.brand = brand;
		this.model = model;
		this.colour = colour;
		this.price = price;
		this.status = status;
	}
	public Car() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Car [carId=" + carId + ", carName=" + carName + ", brand=" + brand + ", model=" + model + ", colour="
				+ colour + ", price=" + price + ", status=" + status + ", image=" + image + "]";
	}
	public void setImage(byte[] imageData) {
		// TODO Auto-generated method stub
		
	}
    
    
}