package com.register.controller;


import java.io.File;
import java.io.IOException;
import java.lang.System.Logger;
import java.nio.channels.ReadPendingException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Principal;
import java.util.List;
import java.util.Optional;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.register.model.Car;
import com.register.services.CarService;


import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/cars")
public class CarController {

	//use carservices
    private final CarService carService;

    //create a model
    Car car= new Car();

	private Integer carId;
    
    private static final org.slf4j.Logger logger = LoggerFactory.getLogger(CarController.class);
    
    	

		
    //use carcontroller
    @Autowired
    public CarController(CarService carService) {
        this.carService = carService;
    }

    // Display the list of cars
    @GetMapping
    public String listCars(Model model) {
        model.addAttribute("cars", carService.findAllCars());
        return "car-list";
    }
    
//    //pagination
//    @GetMapping("/carlist")
//    public String listCars(@RequestParam(defaultValue = "1") int page,
//                           @RequestParam(defaultValue = "10") int size,
//                           @RequestParam(defaultValue = "carName") String sort,
//                           Model model) {
//
//        // Perform pagination
//        Page<Car> carPage = (Page<Car>) carService.getCarById(PageRequest.of(page - 1, size, Sort.by(sort)));
//
//        
//        List<Car> cars = carPage.getContent();
//        int totalPages = carPage.getTotalPages();
//        int currentPage = carPage.getNumber() + 1; 
//
//        model.addAttribute("cars", cars);
//        model.addAttribute("totalPages", totalPages);
//        model.addAttribute("currentPage", currentPage);
//        model.addAttribute("pageSize", size);
//        model.addAttribute("sort", sort);
//
//        return "car-list"; 
//    }
//    
    
    

 // Display the list of cars for users
    @GetMapping("/show")
    public String UserlistCars(Model model) {
        model.addAttribute("cars", carService.findAllCars());
        return "userviewcar-list";
    }
    // Display a form for adding a new car
    @GetMapping("/add")
    public String showAddCarForm(Model model) {
    	
        model.addAttribute("car", new Car());
        car.setPrice(0);
        return "add-car";
    }
    
    
//    // Process the form submission to add a new car
//    @PostMapping("/add")
//    public String addCar(@ModelAttribute Car car) {
//    	car.setStatus("Available");
//        carService.addCar(car);        
//        return "redirect:/cars";
//    }
    


    
 // Process the form submission to add a new car
    @PostMapping("/add")
    public String addCar(@ModelAttribute Car car, @RequestParam("imageFile") MultipartFile file, Principal principal, HttpSession session) {
        car.setStatus("Available");
        try {
            if (principal != null && !file.isEmpty()) {
                String username = principal.getName();
                Car user = this.carService.findByCarName(username);

                if (user != null) {
                    car.setImage(file.getOriginalFilename());

                    String uploadDir = new ClassPathResource("static/img").getFile().getAbsolutePath();
                    Path filePath = Paths.get(uploadDir, file.getOriginalFilename());

                    Files.createDirectories(filePath.getParent());
                    Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

                    System.out.println("Image Is Uploaded");
                } else {
                    System.out.println("User not found.");
                }
            } else {
                System.out.println("User not authenticated or File Is Empty.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Car Details: " + car.toString());

        car.setStatus("Available");
        carService.addCar(car);
        return "redirect:/cars";
    }


    // Display a form for updating an existing car
    @GetMapping("/edit/{id}")
    public String showEditCarForm(@PathVariable Integer id, Model model) {
        Car car = carService.findCarById(id);
        model.addAttribute("car", car);
        return "edit-car";
    }

    // Process the form submission to update an existing car
    @PostMapping("/edit/{id}")
    public String editCar(@PathVariable Integer id, @ModelAttribute Car updatedCar) {
        carService.updateCar(id, updatedCar);
        return "redirect:/cars";
    }

    // Delete an existing car
    @GetMapping("/delete/{id}")
    public String deleteCar(@PathVariable Integer id) {
        carService.deleteCar(id);
        return "redirect:/cars";
    }
    
    //view an existing car
    @GetMapping("/view/{id}")
    public String viewCar(@PathVariable Integer id, Model model) {
        Car car = carService.findCarById(id);
        model.addAttribute("car", car);
        return "view-car";
    }
    
  //view all existing car for users
    @GetMapping("show/view/{id}")
    public String userviewCar(@PathVariable Integer id, Model model) {
        Car car = carService.findCarById(id);
        model.addAttribute("car", car);
        return "userview-car";
    }



//    //when user want to buy the car
//    @GetMapping("/buy/{carId}")
//    public String buyCaruser(@PathVariable("carId") int carId, HttpSession session) {  	
//        session.setAttribute("carId", carId);
//        Car car1=carService.findCarById(carId);
//        car1.setStatus("pending");        
//        carService.updateCar(carId, car1);
//        System.out.println("car---"+car1);
//        return "redirect:/cars/show";
//    }
    
 // when user wants to buy the car
    @GetMapping("/buy/{carId}")
    public String buyCaruser(@PathVariable("carId") int carId, HttpSession session) {
        session.setAttribute("carId", carId);
        Car car1 = carService.findCarById(carId);
        car1.setStatus("pending");
        carService.updateCar(carId, car1);
        
        // Log the information
        logger.info("Car purchase initiated. Car ID: {}, Status: {}", carId, car1.getStatus());

        return "redirect:/cars/show";
    }
    
    @PostMapping("/cars/updateStatus/{carId}")
    public ResponseEntity<String> updateCarStatus(@PathVariable("carId") int carId, @RequestParam("status") String status) {
        Car car = carService.findCarById(carId);
        if (car != null) {
            car.setStatus(status);
            carService.updateCar(carId, car);

            // Log the status update information
            logger.info("Car status updated. Car ID: {}, New Status: {}", carId, status);

            return ResponseEntity.ok("Car status updated successfully.");
        } else {
            return ResponseEntity.badRequest().body("Car not found.");
        }
    }
    
    @GetMapping("/{carId}")
    public ResponseEntity<Car> getCarDetails(@PathVariable Integer carId) {
        Car car = carService.getCarById(carId);
        return ResponseEntity.ok(car);
    }

    @PostMapping("/{carId}/updateStatus/{status}")
    public ResponseEntity<Car> updateCarStatus(
            @PathVariable Integer carId,
            @PathVariable String status
    ) {
        Car updatedCar = carService.updateCar(carId, status);
        return ResponseEntity.ok(updatedCar);
    }
    

    
    @GetMapping("/dashboard")
    public String showDashboard(Model model) {
        long totalCars = carService.getTotalCarCount();
        model.addAttribute("totalCars", totalCars);
        return "dashboard";
    }
    
}

