package com.register.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.register.model.ResourceNotFoundException;

@RestController
@RequestMapping("/api")
public class MyController {

    @GetMapping("/resource/{id}")
    public String getResource(@PathVariable Long id) {
        // Logic to fetch the resource
        // If resource is not found, throw ResourceNotFoundException
        throw new ResourceNotFoundException("Resource with id " + id + " not found");
    }
}
