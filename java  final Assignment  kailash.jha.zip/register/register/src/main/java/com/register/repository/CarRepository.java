package com.register.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.register.model.Car;


import java.util.List;




@Repository
public interface CarRepository extends JpaRepository<Car, Integer> {

    // Use the correct property name in your Car entity
    Car findByCarName(String carName);
//    long getTotalCarCount();
    List<Car> findByCarId(int carId);
    List<Car> findByStatus(String status);
    @Modifying
    @Query("UPDATE Car car SET car.status = :status WHERE car.carId = :carId")
    void updateCar(@Param("carId") int carId, @Param("status") String status);
    
    
    //pagination 
   //searching 
    
//    List<Car> searchUsers(String keyword);
}