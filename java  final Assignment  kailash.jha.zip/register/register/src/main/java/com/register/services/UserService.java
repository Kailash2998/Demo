package com.register.services;

import com.register.model.User;

public interface UserService {

	public User saveUser(User user);
	public void removeSessionMessage();
	void updateStatus(int userId, String newStatus);
	
}
