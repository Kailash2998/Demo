package com.tets.repository;
import java.util.List;
import com.tets.model.User;

public interface UserRepository {
	List<User> getAllUsers();

	User getUserById(Long id);

	void createUser(User user);

	void updateUser(Long id, User user);

	void deleteUser(Long id);

	List<User> searchUsers(String keyword);



	
}
