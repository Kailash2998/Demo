//import our packages 
package com.tets.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

//class name
@Configuration
public class WebClientConfig {

	//web client
    @Bean
    public WebClient.Builder webClientBuilder() {
        return WebClient.builder();
    }
}

