//package import what the need
package com.tets.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.tets.model.User;
import com.tets.repository.UserRepository;

//class
@Controller
@RequestMapping("/users")
public class UserController {

	@Autowired
	private final UserRepository userRepository;

	public UserController(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	//get mapping for open the form 
	@GetMapping("/create")
	public String showCreateUserForm(Model model) {
		model.addAttribute("user", new User());
		return "createUser";
	}

	//post mapping  fill the data
	@PostMapping("/create")
	public String createUser(@ModelAttribute User user, RedirectAttributes redirectAttributes) {
		userRepository.createUser(user);
		redirectAttributes.addFlashAttribute("successMessage", "User created successfully!");
		return "redirect:/users";
	}

	//get mapping for open the edit form 
	@GetMapping("/edit/{id}")
	public String showEditUserForm(@PathVariable Long id, Model model) {
		User user = userRepository.getUserById(id);
		model.addAttribute("user", user);
		return "editUser";
	}

	//post mapping after fill the data
	@PostMapping("/edit/{id}")
	public String editUser(@PathVariable Long id, @ModelAttribute User user, RedirectAttributes redirectAttributes) {
		userRepository.updateUser(id, user);
		redirectAttributes.addFlashAttribute("successMessage", "User updated successfully!");
		return "redirect:/users";
	}

	//get mapping delete the data 
	@GetMapping("/delete/{id}")
	public String deleteUser(@PathVariable Long id, RedirectAttributes redirectAttributes) {
		userRepository.deleteUser(id);
		redirectAttributes.addFlashAttribute("successMessage", "User deleted successfully!");
		return "redirect:/users";
	}

	//for view the data
	@GetMapping("/view/{id}")
	public String viewUser(@PathVariable Long id, Model model) {
		try {
			User user = userRepository.getUserById(id);

			if (user != null) {
				model.addAttribute("user", user);
				return "userDetails";
			} else {
				return "redirect:/users";
			}
		} catch (Exception e) {
			e.printStackTrace(); 

			return "error";
		}
	}

	//get mapping for show all the data in table form
	@GetMapping
	public String getAllUsers(Model model, @RequestParam(required = false) String keyword) {
		List<User> users;

		if (keyword != null && !keyword.isEmpty()) {
			users = userRepository.searchUsers(keyword);

			if (users.isEmpty()) {
				model.addAttribute("errorMessage", "No users found with the specified keyword.");
				return "userList";
			}
		} else {
			users = userRepository.getAllUsers();
		}

		model.addAttribute("users", users);
		return "userList";
	}

	//get mapping for search the data whatever 
	@GetMapping("/search")
	public String searchUserById(@RequestParam Long id, Model model) {
		try {
			User user = userRepository.getUserById(id);

			if (user != null) {
				model.addAttribute("user", user);
				return "userDetails";
			} else {
				model.addAttribute("error", "User not found");
				return "error";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "error";
		}
	}
}
