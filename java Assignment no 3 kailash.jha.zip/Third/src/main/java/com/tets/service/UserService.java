//import the package what ever need
package com.tets.service;

import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.tets.model.User;
import com.tets.repository.UserRepository;

import reactor.core.publisher.Mono;

@Service
public class UserService implements UserRepository {

    private final Logger logger = LoggerFactory.getLogger(UserService.class);

    private final String apiUrl = "https://jsonplaceholder.typicode.com/users";

    private final WebClient webClient;

    @Autowired
    public UserService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.baseUrl(apiUrl).build();
    }


    @Override
    public List<User> getAllUsers() {
        try {
            return webClient.get()
                    .retrieve()
                    .bodyToFlux(User.class)
                    .collectList()
                    .doOnSuccess(users -> {
                        logger.info("Request successful. Retrieved {} users", users.size());
                    })
                    .block();
        } catch (Exception e) {
            logger.error("Error retrieving all users", e);
            return Collections.emptyList();
        }
    }

    @Override
    public User getUserById(Long id) {
        try {
            return webClient.get().uri("/{id}", id).retrieve().bodyToMono(User.class).block();
        } catch (Exception e) {
            logger.error("Error retrieving user by id: {}", id, e);
            return null;
        }
    }

    @Override
    public void createUser(User user) {
        try {
            webClient.post()
                    .body(Mono.just(user), User.class)
                    .retrieve()
                    .toBodilessEntity()
                    .doOnSuccess(responseEntity -> {
                        HttpStatus statusCode = (HttpStatus) responseEntity.getStatusCode();
                        logger.info("User created successfully. Status code: {}", statusCode);
                    })
                    .block();
            logger.info("User created successfully: {}", user);
        } catch (Exception e) {
            logger.error("Error creating user: {}", user, e);
        }
    }

    @Override
    public void updateUser(Long id, User user) {
        try {
            webClient.put()
                    .uri("/{id}", id)
                    .body(Mono.just(user), User.class)
                    .retrieve()
                    .toBodilessEntity()
                    .doOnSuccess(responseEntity -> {
                        HttpStatus statusCode = (HttpStatus) responseEntity.getStatusCode();
                        logger.info("User updated successfully. Status code: {}", statusCode);
                    })
                    .block();
            logger.info("User updated successfully: {}", user);
        } catch (Exception e) {
            logger.error("Error updating user with id {}: {}", id, user, e);
        }
    }

    @Override
    public void deleteUser(Long id) {
        try {
            webClient.delete()
                    .uri("/{id}", id)
                    .retrieve()
                    .toBodilessEntity()
                    .doOnSuccess(responseEntity -> {
                        HttpStatus statusCode = (HttpStatus) responseEntity.getStatusCode();
                        logger.info("User deleted successfully. Status code: {}", statusCode);
                    })
                    .block();
            logger.info("User deleted successfully with id: {}", id);
        } catch (Exception e) {
            logger.error("Error deleting user with id: {}", id, e);
        }
    }

    @Override
    public List<User> searchUsers(String keyword) {
        try {
            return webClient.get()
                    .uri(uriBuilder -> uriBuilder.queryParam("name", keyword).build())
                    .retrieve()
                    .bodyToFlux(User.class)
                    .collectList()
                    .doOnSuccess(responseEntity -> {
                        HttpStatus statusCode = (HttpStatus) ((ResponseEntity<Void>) responseEntity).getStatusCode();
                        logger.info("Request successful. Status code: {}", statusCode);
                    })
                    .block();
        } catch (Exception e) {
            logger.error("Error searching users with keyword: {}", keyword, e);
            return Collections.emptyList();
        }
    }
}
